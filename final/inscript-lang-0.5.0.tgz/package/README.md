# InScript 🎮

**A game-focused programming language** — clean syntax, batteries included.

```inscript
// Everything a game needs is already built in
scene Main {
    let player = Entity {
        pos:    Vec2(400, 300),
        health: 100,
        speed:  180.0,
    }

    on_update(dt: float) {
        let dir = Input.wasd()
        player.pos += dir * player.speed * dt

        if Input.just_pressed(Key.Space) {
            spawn(Bullet { pos: player.pos, vel: Vec2(0, -600) })
        }
    }

    on_draw {
        Draw.sprite("ship.png", player.pos)
        Draw.hud_text("HP: " + player.health, Vec2(10, 10))
    }
}
```

## Features

| Feature | Status |
|---------|--------|
| Type-safe syntax (Rust-inspired) | ✅ |
| Entity-Component System | ✅ |
| 2D/3D Physics | ✅ |
| Shader System (GLSL/WGSL/HLSL) | ✅ |
| Networking & Multiplayer | ✅ |
| Game AI (FSM/BTree/NavMesh/Boids) | ✅ |
| Declarative UI (HUD, menus) | ✅ |
| Bytecode Compiler + VM | ✅ |
| Web Export (HTML5/PWA) | ✅ |

## Install

```bash
pip install inscript-lang
```

## Quick Start

```bash
# Run a game
inscript mygame.ins

# Interactive REPL
inscript --repl

# Build for web
inscript build --target web mygame.ins

# Type-check only
inscript --check mygame.ins
```

## Language Overview

```inscript
// Variables
let x: int = 42
let name = "Ada"          // type inferred
const MAX_SPEED = 600.0

// Functions
fn lerp(a: float, b: float, t: float) -> float {
    return a + (b - a) * t
}

// Structs
struct Bullet {
    pos:   Vec2
    vel:   Vec2
    dmg:   int = 10
}

// Pattern matching
match input.key {
    Key.W | Key.Up    => player.vel.y = -speed
    Key.S | Key.Down  => player.vel.y =  speed
    _                 => player.vel.y =  0
}

// Closures
let enemies = world.entities.filter(|e| e.tag == "enemy")

// Networking
let srv = Network.create_server(port: 7777)
srv.on_connect = |client| { broadcast({ type: "joined", id: client.id }) }

// AI
ai Enemy {
    state Idle {
        on_update(dt) { if can_see(player) { switch_to(Chase) } }
    }
    state Chase {
        on_update(dt) { navigate_to(player.pos) }
    }
}
```

## Architecture

```
InScript Source (.ins)
        │
        ▼
   Lexer → Tokens
        │
        ▼
   Parser → AST
        │
        ▼
   Analyzer (type checker)
        │
   ┌────┴────┐
   ▼         ▼
Tree-walk  Bytecode      ← Phase 19: 10-100× faster
Interpreter Compiler
              │
              ▼
         BytecodeVM
              │
              ▼
         .insb binary
```

## Deployment Targets

```bash
inscript build --target web     game.ins   # → HTML5 / PWA
inscript build --target android game.ins   # → APK / AAB
inscript build --target ios     game.ins   # → IPA (macOS required)
inscript build --target desktop game.ins   # → EXE / APP / AppImage
```

## License

MIT
